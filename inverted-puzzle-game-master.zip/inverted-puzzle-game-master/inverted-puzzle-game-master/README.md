# inverted-puzzle-game
A game for CISC226 that is half puzzle, half level navigation
